# ldpc-3gpp-matlab
Matlab simulations of the encoder and decoder for the New Radio LDPC code from 3GPP Release 15. The corresponding standards document (TS38.212) can be downloaded from the 'Versions' tab at...
https://portal.3gpp.org/desktopmodules/Specifications/SpecificationDetails.aspx?specificationId=3214

The best way to get started with this code is to run plot_BLER_vs_SNR.m

Note that a license to the Matlab Communications Toolbox is required to run this code...
https://www.mathworks.com/products/communications.html
