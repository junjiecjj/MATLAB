# OFDM
A MATLAB program to help understand OFDM.

For process analysis, please click the link below:
OFDM完整仿真过程及解释（MATLAB） - 子木的文章 - 知乎
https://zhuanlan.zhihu.com/p/57967971
